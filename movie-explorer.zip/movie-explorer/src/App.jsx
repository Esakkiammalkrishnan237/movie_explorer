import { useEffect, useState } from 'react'
import './App.css'
import { getPopularMovies, searchMovies, getMoviesByCategory} from './services/movieApi'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import MovieDetails from './pages/MovieDetails'

function Home() {
  const [movies, setMovies] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')

  useEffect(() => {
    async function loadMovies() {
      try {
        const data = await getPopularMovies()
        setMovies(data)
      } catch (err) {
        setError('Failed to load movies')
      } finally {
        setLoading(false)
      }
    }

    loadMovies()
  }, [])

  async function handleSearch() {
    if (!search.trim()) return

    try {
      setLoading(true)
      setError('')

      const data = await searchMovies(search)
      setMovies(data)
    } catch (err) {
      setError('Failed to search movies')
    } finally {
      setLoading(false)
    }
  }
async function handleCategory(categoryId) {
  try {
    setLoading(true)
    setError('')
    setCategory(categoryId)

    const data = await getMoviesByCategory(categoryId)
    setMovies(data)
  } catch (err) {
    setError('Failed to load category movies')
  } finally {
    setLoading(false)
  }
}
  return (
    <div className="app">

      <header className="navbar">
        <h1>🎬கனவுத்திரை</h1>
      </header>

      <main>

        <section className="hero">
          <h2>Discover Your Favorite Movies</h2>
          <p>Search and explore thousands of movies</p>

          <div className="search-box">
            <input
              type="text"
              placeholder="Search movies..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

            <button onClick={handleSearch}>
              Search
            </button>
          </div>
          <div className="category-buttons">
  <button onClick={() => handleCategory(28)}>Action</button>
  <button onClick={() => handleCategory(35)}>Comedy</button>
  <button onClick={() => handleCategory(27)}>Horror</button>
  <button onClick={() => handleCategory(878)}>Sci-Fi</button>
  <button onClick={() => handleCategory(10749)}>Romance</button>
</div>
        </section>

        <section className="movies-section">

          <h2>Popular Movies</h2>

        {loading && <div className="loader"></div>}
{loading && <div className="loader"></div>}

{error && (
  <p className="error-message">
    {error}
  </p>
)}
          <div className="movie-grid">

            {movies.map((movie) => (

              <div className="movie-card" key={movie.id}>

                <Link to={`/movie/${movie.id}`}>

                  {movie.poster_path ? (
                    <img
                      src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                      alt={movie.title}
                    />
                  ) : (
                    <div className="no-poster">
                      🎬
                      <p>No Poster</p>
                    </div>
                  )}

                </Link>

                <h3>{movie.title}</h3>

                <p>
                  ⭐ {movie.vote_average.toFixed(1)}
                </p>

                <p>{movie.release_date}</p>

              </div>

            ))}

          </div>

        </section>

      </main>

    </div>
  )
}

function App() {
  return (
    <BrowserRouter>

      <Routes>

        <Route path="/" element={<Home />} />

        <Route
          path="/movie/:id"
          element={<MovieDetails />}
        />

      </Routes>

    </BrowserRouter>
  )
}

export default App