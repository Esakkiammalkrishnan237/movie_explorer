import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getMovieDetails } from '../services/movieApi'

function MovieDetails() {
  const { id } = useParams()

  const [movie, setMovie] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    async function loadMovie() {
      try {
        const data = await getMovieDetails(id)
        setMovie(data)
      } catch (err) {
        setError('Failed to load movie details')
      } finally {
        setLoading(false)
      }
    }

    loadMovie()
  }, [id])

  if (loading) {
    return <h2>Loading movie details...</h2>
  }

  if (error) {
    return <h2>{error}</h2>
  }

  return (
    <div className="details-page">

      <Link to="/">← Back to Movies</Link>

      <div className="details-container">

        <img
          src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
          alt={movie.title}
        />

        <div className="details-info">

          <h1>{movie.title}</h1>

          <p>⭐ Rating: {movie.vote_average.toFixed(1)}</p>

          <p>📅 Release Date: {movie.release_date}</p>

          <p>
            🎭 Genre:{' '}
            {movie.genres.map((genre) => genre.name).join(', ')}
          </p>

          <h3>Overview</h3>

          <p>{movie.overview}</p>

        </div>

      </div>

    </div>
  )
}

export default MovieDetails